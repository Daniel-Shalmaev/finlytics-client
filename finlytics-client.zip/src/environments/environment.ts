export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:7168/api'
};
