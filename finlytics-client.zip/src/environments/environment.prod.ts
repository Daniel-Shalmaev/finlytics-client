export const environment = {
  production: true,
  apiBaseUrl: 'https://your-production-server.com/api'
};
