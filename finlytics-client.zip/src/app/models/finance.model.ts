export interface FinanceData {
    date: string;
    income: number;
    outcome: number;
  }
  